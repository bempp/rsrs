use super::{
    box_skeletonisation::{
        IdTimesOperations, LuTimesOperations, Rank, Skel, UpdateTimes, UpdateTimesOperations,
    },
    rsrs_factors::{DiagBoxFactor, LuTimes, PivotMethod, RsrsFactors, RsrsFactorsImpl},
    sketch::SketchData,
    tree_indexing::{TreeData, TreeIndexing},
};
use crate::rsrs::{
    rsrs_factors::{LocalFromSpaces, RsrsOperator},
    sketch::SamplingSpace,
};
use crate::{
    rsrs::rsrs_factors::{IdTimes, Times},
    utils::least_squares_and_null::NullMethod,
};
use crate::{
    rsrs::{rsrs_factors::FactType, sketch::Stabilise},
    utils::io::IOData,
};
use crate::{
    rsrs::{
        rsrs_factors::{CommutativeFactors, CommutativeFactorsOperations, Factor},
        sketch::UpdateType,
    },
    utils::least_squares_and_null::BlockExtractionMethod,
};
use bempp_octree::{MortonKey, Octree};
use mpi::traits::CommunicatorCollectives;
use rand_distr::{Distribution, Standard, StandardNormal};
use rayon::{
    iter::{IndexedParallelIterator, IntoParallelRefIterator, ParallelIterator},
    ThreadPoolBuilder,
};
use rlst::dense::{linalg::lu::MatrixLu, tools::RandScalar};
pub use rlst::prelude::*;
use rustc_hash::FxHashSet;
use serde::Deserialize;
use std::{
    collections::HashMap,
    fmt::Write,
    path::Path,
    time::{Duration, Instant},
}; // Ensure IndexableSpace is in scope
type Inds<T> = Vec<Vec<T>>;
use crate::rsrs::rsrs_factors::LevelIdFactors;

#[derive(Debug)]
pub struct LimitingLevel {
    pub level: usize,
    pub num_boxes: usize,
    pub active_points: usize,
    pub elapsed_time: u128,
}

#[derive(Debug)]
pub struct LimitingFactors {
    pub min_samples: usize,
    pub max_level: usize,
    pub limiting_level: LimitingLevel,
}

#[derive(Debug)]
pub struct Stats {
    pub sampling_time: Vec<u128>,
    pub sampling_extraction_time: u128,
    pub id_times: Vec<IdTimes>,
    pub tot_id_time: u128,
    pub lu_times: Vec<LuTimes>,
    pub tot_lu_time: u128,
    pub update_times: Vec<UpdateTimes>,
    pub total_elapsed_time: u128,
    pub total_elapsed_time_wo_sampling: u128,
    pub dim: usize,
    pub extraction_time: u128,
    pub residual_size: usize,
    pub ranks: Vec<usize>,
    pub box_sizes: Vec<usize>,
    pub near_field_sizes: Vec<usize>,
    pub dec_boxes_per_level: Vec<usize>,
    pub index_calculation: u128,
    pub sorting_near_field: u128,
    pub residual_calculation: u128,
    pub limiting_factors: LimitingFactors,
}

pub struct Rsrs<Item: RlstScalar> {
    level_indexing: TreeData,
    pub y_data: SketchData<Item>,
    pub z_data: SketchData<Item>,
    dim: usize,
    ind_s: Inds<usize>,
    ind_r: Inds<usize>,
    box_types: Vec<BoxType<Real<Item>>>,
    target_inds: Inds<usize>,
    near_inds: Inds<usize>,
    pub active_samples: usize,
    pub stats: Stats,
    options: RsrsOptions<Item>,
}

#[derive(Debug, Clone)]
pub enum BoxType<Item: RlstScalar> {
    Merged(usize),
    Full(Real<Item>),
}

#[derive(Debug, Clone, Deserialize)]
pub enum RankPicking {
    Min,
    DoubleMin,
    Max,
    Avg,
    Mid,
    Tol,
}

#[derive(Debug, Clone)]
pub struct IdOptions<Item: RlstScalar> {
    pub null_method: NullMethod,
    pub qr_method: RankRevealingQrType<Real<Item>>,
    pub tol_null: Real<Item>,
    pub tol_id: Real<Item>,
}

#[derive(Debug, Clone)]
pub struct ExtractOptions<Item: RlstScalar> {
    pub block_extraction_method: BlockExtractionMethod,
    pub pivot_method: PivotMethod,
    pub tol_lstsq: Real<Item>,
}

#[derive(Debug, Clone)]
pub struct SketchingOptions {
    pub oversampling: usize,
    pub oversampling_diag_blocks: usize,
    pub initial_num_samples: usize,
    pub stabilise: Stabilise,
    pub save_samples: bool,
}

#[derive(Debug, Clone)]
pub struct RsrsOptions<Item: RlstScalar> {
    pub fact_type: FactType,
    pub sketching: SketchingOptions,
    pub id_options: IdOptions<Item>,
    pub lu_options: ExtractOptions<Item>,
    pub extract_db_options: ExtractOptions<Item>,
    pub min_rank: usize,
    pub hermitian: bool,
    pub min_level: usize,
    pub rank_picking: RankPicking,
    pub num_threads: usize,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(bound = "Real<Item>: Deserialize<'de>")]
pub struct RsrsArgs<Item: RlstScalar> {
    oversampling: usize,
    oversampling_diag_blocks: usize,
    initial_num_samples: usize,
    stabilise: Stabilise,
    null_method: NullMethod,
    qr_method: RankRevealingQrType<Real<Item>>,
    near_block_extraction_method: BlockExtractionMethod,
    diag_block_extraction_method: BlockExtractionMethod,
    lu_pivot_method: PivotMethod,
    diag_pivot_method: PivotMethod,
    tol_null: Real<Item>,
    tol_id: Real<Item>,
    tol_ext_near: Real<Item>,
    tol_diag_ext: Real<Item>,
    min_rank: usize,
    min_level: usize,
    hermitian: bool,
    rank_picking: RankPicking,
    fact_type: FactType,
    save_samples: bool,
    num_threads: usize,
}

impl<Item> RsrsArgs<Item>
where
    Item: RlstScalar,
{
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        oversampling: usize,
        oversampling_diag_blocks: usize,
        initial_num_samples: usize,
        stabilise: Stabilise,
        null_method: NullMethod,
        qr_method: RankRevealingQrType<Real<Item>>,
        near_block_extraction_method: BlockExtractionMethod,
        diag_block_extraction_method: BlockExtractionMethod,
        lu_pivot_method: PivotMethod,
        diag_pivot_method: PivotMethod,
        tol_null: Real<Item>,
        tol_id: Real<Item>,
        tol_ext_near: Real<Item>,
        tol_diag_ext: Real<Item>,
        min_rank: usize,
        min_level: usize,
        hermitian: bool,
        rank_picking: RankPicking,
        fact_type: FactType,
        save_samples: bool,
        num_threads: usize,
    ) -> Self {
        Self {
            oversampling,
            oversampling_diag_blocks,
            initial_num_samples,
            stabilise,
            null_method,
            qr_method,
            near_block_extraction_method,
            diag_block_extraction_method,
            lu_pivot_method,
            diag_pivot_method,
            tol_null,
            tol_id,
            tol_ext_near,
            tol_diag_ext,
            min_rank,
            min_level,
            hermitian,
            rank_picking,
            fact_type,
            save_samples,
            num_threads,
        }
    }
}

impl<Item: RlstScalar + std::fmt::Display> RsrsOptions<Item> {
    pub fn new(args: Option<RsrsArgs<Item>>) -> Self {
        let args = match args {
            Some(input) => input,
            None => RsrsArgs::new(
                8,
                16,
                420,
                Stabilise::False,
                NullMethod::Projection,
                RankRevealingQrType::RRQR,
                BlockExtractionMethod::LuLstSq,
                BlockExtractionMethod::LuLstSq,
                PivotMethod::Lu(1e-10),
                PivotMethod::Lu(0.0),
                Item::real(1e-10),
                Item::real(1e-2),
                Item::real(1e-10),
                Item::real(1e-10),
                4,
                1,
                true,
                RankPicking::Min,
                FactType::Joint,
                false,
                num_cpus::get(),
            ),
        };

        let min_rank = if args.tol_id > num::One::one() {
            let k = num::ToPrimitive::to_usize(&args.tol_id).unwrap();
            println!("For tolerances > 1, ID will use this as a fixed rank instead. This fixed rank is: {k}");

            if k <= args.min_rank {
                k
            } else {
                args.min_rank
            }
        } else {
            args.min_rank
        };

        Self {
            sketching: SketchingOptions {
                oversampling: args.oversampling,
                oversampling_diag_blocks: args.oversampling_diag_blocks,
                initial_num_samples: args.initial_num_samples,
                stabilise: args.stabilise,
                save_samples: args.save_samples,
            },
            id_options: IdOptions {
                null_method: args.null_method,
                qr_method: args.qr_method,
                tol_null: args.tol_null,
                tol_id: args.tol_id,
            },
            lu_options: ExtractOptions {
                block_extraction_method: args.near_block_extraction_method,
                pivot_method: args.lu_pivot_method,
                tol_lstsq: args.tol_ext_near,
            },
            extract_db_options: ExtractOptions {
                block_extraction_method: args.diag_block_extraction_method,
                pivot_method: args.diag_pivot_method,
                tol_lstsq: args.tol_diag_ext,
            },
            fact_type: args.fact_type,
            min_rank,
            min_level: args.min_level,
            hermitian: args.hermitian,
            rank_picking: args.rank_picking,
            num_threads: args.num_threads,
        }
    }

    pub fn to_identifier(&self) -> String {
        let mut id = String::from("rsrs");

        write!(
            &mut id,
            "_null_{:?}_toln_{:e}",
            self.id_options.null_method, self.id_options.tol_null,
        )
        .unwrap();

        match self.sketching.stabilise {
            Stabilise::True(alpha) => write!(
                &mut id,
                "_os_{os}_osdiag_{osdiag}_initsam_{init}_stabilised_{alpha:.e}",
                os = self.sketching.oversampling,
                osdiag = self.sketching.oversampling_diag_blocks,
                init = self.sketching.initial_num_samples,
                alpha = alpha
            )
            .unwrap(),
            Stabilise::False => write!(
                &mut id,
                "_os_{os}_osdiag_{osdiag}_initsam_{init}",
                os = self.sketching.oversampling,
                osdiag = self.sketching.oversampling_diag_blocks,
                init = self.sketching.initial_num_samples
            )
            .unwrap(),
        };

        match self.id_options.qr_method{
            RankRevealingQrType::RRQR => write!(
            &mut id,
            "_mrnk_{}_mlvl_{}_herm_{}_rpick_{:?}_next_{:?}_tolextn_{:e}_db_ext_{:?}_tol_lstsq_{:e}_rrqr",
            self.min_rank,
            self.min_level,
            self.hermitian,
            self.rank_picking,
            self.lu_options.block_extraction_method,
            self.lu_options.tol_lstsq,
            self.extract_db_options.block_extraction_method,
            self.extract_db_options.tol_lstsq
        )
        .unwrap(),
            RankRevealingQrType::SRRQR(f) => write!(
            &mut id,
            "_mrnk_{}_mlvl_{}_herm_{}_rpick_{:?}_next_{:?}_tolextn_{:e}_db_ext_{:?}_tol_lstsq_{:e}_srrqr_{:e}",
            self.min_rank,
            self.min_level,
            self.hermitian,
            self.rank_picking,
            self.lu_options.block_extraction_method,
            self.lu_options.tol_lstsq,
            self.extract_db_options.block_extraction_method,
            self.extract_db_options.tol_lstsq,
            f
        )
        .unwrap(),
        };

        id
    }
}

type Real<T> = <T as rlst::RlstScalar>::Real;

fn oversample<Item: RlstScalar>(
    samples: usize,
    oversampling: usize,
    id_tol: <Item as RlstScalar>::Real,
) -> usize {
    if id_tol < num::One::one() {
        samples + (samples / 100) * oversampling
    } else {
        samples + num::ToPrimitive::to_usize(&id_tol).unwrap()
    }
}

fn local_oversample(_min_samples: usize, active_samples: usize) -> usize {
    active_samples
    //min_samples + (active_samples - min_samples) / 2
}

fn auto_min_len(batch_len: usize, num_threads: usize) -> usize {
    if batch_len <= num_threads {
        1
    } else {
        let raw = batch_len / (2 * num_threads);
        raw.max(1).min(32)
    }
}

/*fn build_conflict_graph(
    near_inds: &Vec<Vec<usize>>,
    current_box_indices: &[usize],
) -> Vec<Vec<usize>> {
    let n = current_box_indices.len();

    // Precompute neighbour sets for each *local* index.
    // local i -> box_id = current_box_indices[i]
    let mut neighbour_sets: Vec<FxHashSet<usize>> = Vec::with_capacity(n);
    for &box_id in current_box_indices {
        let mut s = FxHashSet::default();
        s.extend(near_inds[box_id].iter().copied());
        neighbour_sets.push(s);
    }

    // Build symmetric adjacency list
    let mut graph: Vec<Vec<usize>> = vec![Vec::new(); n];

    for i in 0..n {
        for j in (i + 1)..n {
            // conflict if they share any neighbour
            let si = &neighbour_sets[i];
            let sj = &neighbour_sets[j];

            // iterate over smaller set for efficiency
            let (small, big) = if si.len() <= sj.len() {
                (si, sj)
            } else {
                (sj, si)
            };

            let intersects = small.iter().any(|x| big.contains(x));
            if intersects {
                graph[i].push(j);
                graph[j].push(i);
            }
        }
    }

    graph
}

fn greedy_color(graph: &Vec<Vec<usize>>) -> Vec<usize> {
    let n = graph.len();
    let mut color = vec![usize::MAX; n];

    for node in 0..n {
        let mut forbidden = FxHashSet::default();

        // colors of neighbours
        for &nb in &graph[node] {
            if color[nb] != usize::MAX {
                forbidden.insert(color[nb]);
            }
        }

        // smallest non-forbidden color
        let mut c = 0;
        while forbidden.contains(&c) {
            c += 1;
        }
        color[node] = c;
    }

    color
}

fn colors_to_batches(coloring: &[usize]) -> Vec<Vec<usize>> {
    let max_color = *coloring.iter().max().unwrap_or(&0);
    let mut batches = vec![Vec::new(); max_color + 1];

    for (i, &c) in coloring.iter().enumerate() {
        batches[c].push(i);
    }

    batches
}*/

impl<
        Item: RlstScalar
            + MatrixId
            + MatrixNull
            + MatrixInverse
            + MatrixPseudoInverse
            + RandScalar
            + MatrixLu
            + MatrixQr,
    > Rsrs<Item>
where
    StandardNormal: Distribution<Item::Real>,
    Standard: Distribution<Item::Real>,
    LuDecomposition<Item, BaseArray<Item, VectorContainer<Item>, 2>>:
        MatrixLuDecomposition<Item = Item>,
    QrDecomposition<Item, BaseArray<Item, VectorContainer<Item>, 2>>:
        MatrixQrDecomposition<Item = Item>,
    TriangularMatrix<Item>: TriangularOperations<Item = Item>,
    <Item as rlst::RlstScalar>::Real: RandScalar,
    Item: IOData<Item>,
    Item: std::convert::From<<Item as IOData<Item>>::Item>,
{
    pub fn new<C: CommunicatorCollectives>(
        octree: &Octree<'_, C>,
        options: RsrsOptions<Item>,
        dim: usize,
    ) -> Self {
        let level_indexing: TreeData = <TreeData as TreeIndexing>::new(octree);
        let target_inds: Inds<usize> = Vec::new();
        let near_inds: Inds<usize> = Vec::new();
        let ind_s: Inds<usize> = Vec::new();
        let ind_r: Inds<usize> = Vec::new();
        let box_types: Vec<BoxType<Real<Item>>> = Vec::new();
        //et dim = space.dimension();
        let y_data: SketchData<Item> = SketchData::new(dim, false);
        let z_data: SketchData<Item> = SketchData::new(dim, true);
        let id_times = Vec::new();
        let lu_times = Vec::new();
        let update_times = Vec::new();
        let limiting_level = LimitingLevel {
            level: 0,
            num_boxes: 0,
            active_points: 0,
            elapsed_time: 0,
        };
        let limiting_factors = LimitingFactors {
            min_samples: 0,
            max_level: 0,
            limiting_level,
        };

        println!(
            "Current number of threads = {}",
            rayon::current_num_threads()
        );
        let stats = Stats {
            sampling_time: Vec::new(),
            sampling_extraction_time: 0_u128,
            id_times,
            tot_id_time: 0_u128,
            lu_times,
            tot_lu_time: 0_u128,
            update_times,
            total_elapsed_time: 0_u128,
            total_elapsed_time_wo_sampling: 0_u128,
            extraction_time: 0_u128,
            residual_size: 0,
            ranks: Vec::new(),
            box_sizes: Vec::new(),
            near_field_sizes: Vec::new(),
            dec_boxes_per_level: Vec::new(),
            index_calculation: 0_u128,
            sorting_near_field: 0_u128,
            residual_calculation: 0_u128,
            limiting_factors,
            dim,
        };

        Self {
            level_indexing,
            y_data,
            z_data,
            dim,
            ind_s,
            ind_r,
            box_types,
            target_inds,
            near_inds,
            stats,
            active_samples: 0,
            options,
        }
    }

    pub fn get_rsrs_operator<'a, Space, OpImpl>(
        &mut self,
        operator: Operator<OpImpl>,
    ) -> RsrsOperator<'a, Item, Space, RsrsFactors<Item>>
    where
        Space: SamplingSpace<F = Item> + 'a,
        OpImpl: AsApply<Domain = Space, Range = Space>,
        RsrsOperator<'a, Item, Space, RsrsFactors<Item>>:
            LocalFromSpaces<'a, Item, Space, RsrsFactors<Item>>,
    {
        let domain = std::rc::Rc::clone(&operator.domain());
        let range = std::rc::Rc::clone(&operator.range());
        let rsrs_factors = self.run(operator.r());
        // Move rsrs_factors into a Box to extend its lifetime
        let boxed_factors = Box::new(rsrs_factors);
        // Create a static reference by leaking the Box (caller must ensure cleanup if needed)
        let static_factors: &'a mut RsrsFactors<Item> = Box::leak(boxed_factors);

        RsrsOperator::from_local_spaces(static_factors, domain, range)
    }
    pub fn run<Space: SamplingSpace<F = Item>, OpImpl: AsApply<Domain = Space, Range = Space>>(
        &mut self,
        operator: Operator<OpImpl>,
    ) -> RsrsFactors<Item> {
        let num_levels: usize = self.level_indexing.max_level;
        let algo_start: Instant = Instant::now();
        let mut rsrs_factors = <RsrsFactors<Item> as RsrsFactorsImpl<Item>>::new(
            num_levels,
            self.dim,
            &self.options.fact_type,
            self.options.num_threads,
        );
        let start: Instant = Instant::now();
        self.tree_cycle(operator.r(), &mut rsrs_factors);
        let duration = start.elapsed();
        println!("Tree cycle elapsed time: {} s", duration.as_secs());
        println!(
            "Extracting diagonal blocks with {} active samples",
            self.active_samples
        );
        let start: Instant = Instant::now();

        let (diag_box_factors, rows, cols) = self.extract_step();
        rsrs_factors.diag_box_factors = diag_box_factors;
        rsrs_factors.perm_factor.orig_indices = cols;
        rsrs_factors.perm_factor.perm_indices = rows;
        let extraction_time = start.elapsed();
        println!("Extraction time: {:?}s\n", extraction_time.as_secs());
        self.stats.extraction_time = extraction_time.as_millis();
        let duration = algo_start.elapsed();
        self.stats.total_elapsed_time = duration.as_millis();
        let sampling_time =
            self.stats.sampling_extraction_time + self.stats.sampling_time.iter().sum::<u128>();
        self.stats.total_elapsed_time_wo_sampling =
            self.stats.total_elapsed_time.saturating_sub(sampling_time);
        println!(
            "Total elapsed time: {:?} ({}ms for sampling, {}ms for RSRS), with {} active samples\n",
            duration, sampling_time, self.stats.total_elapsed_time_wo_sampling, self.active_samples
        );
        println!("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");

        rsrs_factors
    }

    fn tree_cycle<
        Space: SamplingSpace<F = Item>,
        OpImpl: AsApply<Domain = Space, Range = Space>,
    >(
        &mut self,
        operator: Operator<OpImpl>,
        rsrs_factors: &mut RsrsFactors<Item>,
    ) {
        let mut level: usize = self.level_indexing.max_level;
        let mut level_it = 0;
        let min_level: usize = self.options.min_level;

        while level > min_level {
            println!("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
            let start: Instant = Instant::now();
            self.get_level_indices(level);
            let duration: Duration = start.elapsed();
            println!("Current Level: {level}. Indices computed in {duration:?}\n\n");
            self.stats.index_calculation += duration.as_millis();

            let start: Instant = Instant::now();
            self.level_cycle(operator.r(), rsrs_factors, level_it);
            println!("End level cycle. Summary:");
            println!("-------------------------");
            let duration: Duration = start.elapsed();
            println!("Elapsed time: {} s", duration.as_secs());

            if self.stats.limiting_factors.limiting_level.level == self.level_indexing.current_level
            {
                self.stats.limiting_factors.limiting_level.elapsed_time = duration.as_millis()
            }

            let start: Instant = Instant::now();
            let len_r: usize = self
                .ind_r
                .iter()
                .map(|residual_inds| residual_inds.len())
                .sum();
            let len_s = self.dim - len_r;
            let duration: Duration = start.elapsed();
            self.stats.residual_calculation += duration.as_millis();

            println!("Sketch Points: {len_s}");
            println!("Residual Points: {len_r}");
            println!(
                "Current Number of Samples: {} of which {} are active\n",
                self.y_data.test.shape()[0],
                self.active_samples
            );

            level -= 1;
            level_it += 1;

            if level <= min_level {
                println!("-------------------------");
                println!("\nReached lower level: {level}");
                self.stats.residual_size = len_r;
                let min_oversamples = oversample::<Item>(
                    len_s,
                    self.options.sketching.oversampling_diag_blocks,
                    num::One::one(),
                );
                println!("Minimum samples: {min_oversamples}");

                let (tot_sampling_time, tot_id_update, tot_lu_update) = self.add_samples(
                    min_oversamples,
                    operator.r(),
                    rsrs_factors,
                    level_it,
                    false,
                    false,
                    0_u64,
                );
                self.active_samples = min_oversamples.max(self.active_samples);

                self.stats.sampling_extraction_time = tot_sampling_time;
                let mut update_times = UpdateTimes::new();
                update_times.sum(tot_id_update, tot_lu_update);
                self.stats.update_times.push(update_times);

                break;
            }
        }
    }

    fn level_cycle<
        Space: SamplingSpace<F = Item>,
        OpImpl: AsApply<Domain = Space, Range = Space>,
    >(
        &mut self,
        operator: Operator<OpImpl>,
        rsrs_factors: &mut RsrsFactors<Item>,
        level_it: usize,
    ) {
        let merged_count = self
            .box_types
            .iter()
            .filter(|box_type| matches!(box_type, BoxType::Merged(_rank)))
            .count();
        println!("Number of merged boxes: {merged_count}\n");

        let current_box_indices =
            self.sampling_step(operator.r(), rsrs_factors, level_it == 0, level_it);

        match self.options.fact_type {
            FactType::Joint => {
                self.joint_id_and_lu::<Space>(rsrs_factors, &current_box_indices, level_it)
            }
            FactType::Split => {
                self.split_id_and_lu::<Space>(rsrs_factors, current_box_indices, level_it)
            }
        }
    }

    fn sampling_step<
        Space: SamplingSpace<F = Item>,
        OpImpl: AsApply<Domain = Space, Range = Space>,
    >(
        &mut self,
        operator: Operator<OpImpl>,
        rsrs_factors: &RsrsFactors<Item>,
        start: bool,
        level_it: usize,
    ) -> Vec<usize> {
        let mut box_indices: Vec<usize> = (0..self.target_inds.len()).collect::<Vec<_>>();

        box_indices = box_indices
            .into_iter()
            .filter(|&box_ind| !self.ind_s[box_ind].is_empty())
            .collect::<Vec<_>>();

        box_indices.sort_by_key(|&box_ind| {
            self.ind_s[box_ind].len() + self.get_near_indices(box_ind).len()
        });

        let current_box_indices = box_indices;
        let last_box_index = *current_box_indices.last().unwrap();

        let min_oversamples = oversample::<Item>(
            self.ind_s[last_box_index].len() + self.get_near_indices(last_box_index).len(),
            self.options.sketching.oversampling,
            self.options.id_options.tol_id,
        );

        let min_samples = if start {
            self.options
                .sketching
                .initial_num_samples
                .max(min_oversamples)
        } else {
            min_oversamples
        };

        let load_samples = if start { true } else { false };

        let (tot_sampling_time, tot_id_update, tot_lu_update) = self.add_samples(
            min_samples,
            operator.r(),
            rsrs_factors,
            level_it,
            start,
            load_samples,
            1,
        );

        self.stats.limiting_factors.min_samples = self
            .stats
            .limiting_factors
            .min_samples
            .max(self.active_samples);
        self.active_samples = min_oversamples.max(self.active_samples);

        self.stats.sampling_time.push(tot_sampling_time);
        let mut update_times = UpdateTimes::new();
        update_times.sum(tot_id_update, tot_lu_update);
        self.stats.update_times.push(update_times);

        println!("Active samples: {}\n", self.active_samples);

        current_box_indices
    }

    fn add_samples<
        Space: SamplingSpace<F = Item>,
        OpImpl: AsApply<Domain = Space, Range = Space>,
    >(
        &mut self,
        min_samples: usize,
        operator: Operator<OpImpl>,
        rsrs_factors: &RsrsFactors<Item>,
        level_it: usize,
        start: bool,
        load_samples: bool,
        _seed: u64,
    ) -> (u128, u128, u128) {
        if load_samples {
            if Path::new("test_file.h5").exists() && Path::new("sketch_file.h5").exists() {
                let test = <Item as IOData<Item>>::load("test_file.h5").unwrap();
                let sketch = <Item as IOData<Item>>::load("sketch_file.h5").unwrap();
                let num_existing_samples = test.len() / self.dim;
                self.y_data
                    .test
                    .resize_in_place([num_existing_samples, self.dim]);
                self.y_data
                    .sketch
                    .resize_in_place([num_existing_samples, self.dim]);
                self.y_data
                    .test
                    .data_mut()
                    .iter_mut()
                    .enumerate()
                    .for_each(|(i, d)| {
                        *d = test[i].into();
                    });
                self.y_data
                    .sketch
                    .data_mut()
                    .iter_mut()
                    .enumerate()
                    .for_each(|(i, d)| {
                        *d = sketch[i].into();
                    });

                println!(
                    "{} samples loaded and {} min samples",
                    num_existing_samples, min_samples
                );
            }
        }

        let mut tot_sampling_time = 0_u128;
        let test_shape = self.y_data.test.shape();

        if min_samples > test_shape[0] {
            let extra_samples = min_samples.saturating_sub(self.y_data.test.shape()[0]);
            println!("Sampling step. Sampling new {extra_samples} vectors\n");

            tot_sampling_time += self.y_data.add_samples(
                extra_samples,
                operator.r(),
                &self.options.sketching.stabilise,
                self.options.sketching.save_samples,
                0_u64,
            );

            if !self.options.hermitian {
                let tot_z_sampling_time = self.z_data.add_samples(
                    extra_samples,
                    operator.r(),
                    &self.options.sketching.stabilise,
                    self.options.sketching.save_samples,
                    0_u64,
                );
                tot_sampling_time += tot_z_sampling_time;
            }

            println!("Total samples: {}", self.y_data.test.shape()[0]);
            println!("Sampling time: {tot_sampling_time}ms\n");
        }
        if !start && min_samples > self.active_samples {
            let extra_active_samples = min_samples.saturating_sub(self.active_samples);
            println!("New {extra_active_samples} samples, with {min_samples} min samples.");
            let update_start = self.active_samples;
            let (tot_id_update, tot_lu_update) = self.update_samples(
                update_start,
                extra_active_samples,
                level_it,
                &UpdateType::Both(rsrs_factors),
            );

            println!("Update times: {tot_id_update}ms (ID), {tot_lu_update}ms (LU)");
            return (tot_sampling_time, tot_id_update, tot_lu_update);
        }
        (tot_sampling_time, 0_u128, 0_u128)
    }

    fn update_samples(
        &mut self,
        update_start: usize,
        samples_to_update: usize,
        level: usize,
        update_type: &UpdateType<Item>,
    ) -> (u128, u128) {
        let (mut tot_id_update, mut tot_lu_update) = self.y_data.update_samples(
            update_start,
            samples_to_update,
            level,
            update_type,
            &self.options.fact_type,
            self.options.num_threads,
        );

        if !self.options.hermitian {
            let (tot_z_id_update, tot_z_lu_update) = self.z_data.update_samples(
                update_start,
                samples_to_update,
                level,
                update_type,
                &self.options.fact_type,
                self.options.num_threads,
            );
            tot_id_update += tot_z_id_update;
            tot_lu_update += tot_z_lu_update;
        }

        (tot_id_update, tot_lu_update)
    }

    fn split_id_and_lu<Space: SamplingSpace<F = Item>>(
        &mut self,
        rsrs_factors: &mut RsrsFactors<Item>,
        current_box_indices: Vec<usize>,
        level_it: usize,
    ) {
        let id_step_start: Instant = Instant::now();
        let (id_factors_res, current_box_indices, level_ind_r) =
            self.id_level_iteration::<Space>(&current_box_indices);
        let id_step_duration = id_step_start.elapsed();
        self.stats.tot_id_time += id_step_duration.as_millis();
        println!("ID step in {id_step_duration:?}");
        match &mut rsrs_factors.id_factors {
            LevelIdFactors::Single(level_factors) => {
                level_factors[level_it] = id_factors_res;
                let start_id_update: Instant = Instant::now();
                let update_type = UpdateType::Id(&level_factors[level_it]);
                self.update_samples(0, self.active_samples, level_it, &update_type);
                let update_id_time: Duration = start_id_update.elapsed();

                let mut update_times = UpdateTimes::new();
                update_times.sum(update_id_time.as_millis(), 0_u128);
                self.stats.update_times.push(update_times);

                println!("ID updated in {update_id_time:?}\n");
            }
            LevelIdFactors::Batched(_) => todo!(),
        }
        //rsrs_factors.id_factors[level_it] = id_factors_res;

        rsrs_factors.lu_factors[level_it] =
            self.lu_level_iteration::<Space>(&current_box_indices, &level_ind_r, level_it);
    }
    fn joint_id_and_lu<Space: SamplingSpace<F = Item>>(
        &mut self,
        rsrs_factors: &mut RsrsFactors<Item>,
        current_box_indices: &[usize],
        level_it: usize,
    ) {
        println!("ID and LU step");
        let start = Instant::now();

        // 1. Build independent batches (MIS-based)
        let independent_near_fields = self.group_near_fields(current_box_indices);

        // 2. Build level_near_field_inds once (per level)
        let mut level_near_field_inds: Vec<_> = current_box_indices
            .iter()
            .map(|&box_ind| self.get_near_indices(box_ind))
            .collect();

        let time_independent_nf = start.elapsed();
        self.stats.sorting_near_field += time_independent_nf.as_millis();

        println!(
            "Batches computed in {time_independent_nf:?}, number of batches: {}",
            independent_near_fields.len()
        );

        // --- timing / stats accumulators over all batches at this level ---
        let mut update_lu_batch_time: u128 = 0;
        let mut update_id_batch_time: u128 = 0;
        let mut lu_step_duration: u128 = 0;
        let mut id_step_duration: u128 = 0;

        let mut level_ind_r: Vec<Vec<usize>> = vec![Vec::new(); current_box_indices.len()];
        let inactive_inds: Vec<usize> = Vec::new();

        let mut lu_times = LuTimes::new();
        let mut id_times = IdTimes::new();
        let mut update_times = UpdateTimes::new();
        let mut num_dec_boxes = 0;
        let mut len_sketch = 0;
        let mut len_full_rank = 0;

        // Build pool once, use it for all batches
        let pool = ThreadPoolBuilder::new()
            .num_threads(self.options.num_threads)
            .build()
            .unwrap();

        // Process all batches *sequentially*, each batch using Rayon internally
        let batches_res: Vec<_> = pool.install(|| {
            independent_near_fields
                .into_iter()
                .map(|batch| {
                    // One batch = independent set of LOCAL indices into current_box_indices
                    let mut id_batch: CommutativeFactors<Item> =
                        CommutativeFactorsOperations::new();
                    let mut id_batch_time = IdTimes::new();
                    let mut lu_batch: CommutativeFactors<Item> =
                        CommutativeFactorsOperations::new();
                    let mut lu_batch_time = LuTimes::new();

                    // ---- ID STEP ----
                    let id_step_start = Instant::now();

                    let num_threads = rayon::current_num_threads();
                    let min_len_id = auto_min_len(batch.len(), num_threads);

                    let id_batch_res: Vec<_> = batch
                        .par_iter()
                        .with_min_len(min_len_id)
                        .map(|box_num| {
                            let box_ind = current_box_indices[*box_num];
                            let mut skel_box = <Item as Default>::default();
                            let os = oversample::<Item>(
                                self.target_inds[box_ind].len()
                                    + level_near_field_inds[*box_num].len(),
                                self.options.sketching.oversampling,
                                self.options.id_options.tol_id,
                            );
                            let min_num_samples = local_oversample(os, self.active_samples);

                            let rank = <Item as Skel<Item, Space>>::id_step(
                                &mut skel_box,
                                &self.box_types[box_ind],
                                &self.ind_s[box_ind],
                                &level_near_field_inds[*box_num],
                                &self.y_data,
                                &self.z_data,
                                min_num_samples,
                                &self.options,
                            );

                            (*box_num, box_ind, rank)
                        })
                        .collect();

                    let mut active_batch: Vec<usize> = Vec::new();

                    id_batch_res
                        .into_iter()
                        .for_each(|(box_num, box_ind, result)| match result {
                            Rank::Low(low_rank_result) => {
                                active_batch.push(box_num);

                                level_ind_r[box_num] = low_rank_result.id_factor.ind_r.clone();
                                self.target_inds[box_ind] = low_rank_result.target_inds.clone();
                                self.ind_s[box_ind] = low_rank_result.id_factor.ind_s.clone();
                                self.ind_r.push(low_rank_result.id_factor.ind_r.clone());

                                let box_size = self.target_inds[box_ind].len();

                                let res_id_times = match low_rank_result.id_times {
                                    Times::Lu(_) => IdTimes {
                                        nullification: 0,
                                        id: 0,
                                    },
                                    Times::Id(id_times) => id_times,
                                };

                                id_batch_time.sum(res_id_times.nullification, res_id_times.id);

                                self.stats.ranks.push(self.ind_s[box_ind].len());
                                self.stats.box_sizes.push(box_size);
                                self.stats
                                    .near_field_sizes
                                    .push(low_rank_result.near_field_inds.len());

                                len_sketch += self.ind_s[box_ind].len();
                                num_dec_boxes += 1;

                                id_batch.add_factor(Factor::Id(low_rank_result.id_factor));
                            }
                            Rank::Full(times) => {
                                if let Times::Id(id_times) = times {
                                    id_batch_time.sum(id_times.nullification, id_times.id);
                                }
                                len_full_rank += self.ind_s[box_ind].len();
                            }
                        });

                    id_step_duration += id_step_start.elapsed().as_millis();

                    // update samples after ID
                    let id_batch_start = Instant::now();
                    let update_type = UpdateType::Id(&id_batch);
                    self.update_samples(0, self.active_samples, level_it, &update_type);
                    update_id_batch_time += id_batch_start.elapsed().as_millis();

                    // ---- LU STEP ----
                    if !active_batch.is_empty() {
                        let lu_step_start = Instant::now();

                        let min_len_lu = auto_min_len(active_batch.len(), num_threads);

                        let lu_batch_res: Vec<_> = active_batch
                            .par_iter()
                            .with_min_len(min_len_lu)
                            .filter_map(|box_num| {
                                let skel_box = <Item as Default>::default();
                                let box_ind = current_box_indices[*box_num];
                                let os = oversample::<Item>(
                                    self.target_inds[box_ind].len()
                                        + level_near_field_inds[*box_num].len(),
                                    self.options.sketching.oversampling,
                                    self.options.id_options.tol_id,
                                );
                                let min_num_samples = local_oversample(os, self.active_samples);

                                <Item as Skel<Item, Space>>::lu_step(
                                    &skel_box,
                                    &self.y_data,
                                    &self.z_data,
                                    &level_ind_r[*box_num],
                                    &level_near_field_inds[*box_num],
                                    &inactive_inds,
                                    min_num_samples,
                                    &self.options,
                                )
                                .map(|(lu_factor, lu_times)| (lu_times, lu_factor))
                            })
                            .collect();

                        lu_batch_res
                            .into_iter()
                            .for_each(|(it_lu_times, lu_factor)| {
                                lu_batch.add_factor(Factor::Lu(lu_factor));
                                if let Times::Lu(lu_times) = it_lu_times {
                                    lu_batch_time.sum(lu_times.lu, lu_times.extraction)
                                }
                            });

                        lu_step_duration += lu_step_start.elapsed().as_millis();

                        // update samples after LU
                        let lu_batch_start = Instant::now();
                        let update_type = UpdateType::Lu(&lu_batch);
                        self.update_samples(0, self.active_samples, level_it, &update_type);
                        update_lu_batch_time += lu_batch_start.elapsed().as_millis();
                    }

                    // prune inactive inds (currently no-op if inactive_inds is empty)
                    level_near_field_inds = level_near_field_inds
                        .iter()
                        .map(|inds| {
                            inds.iter()
                                .filter(|el| !inactive_inds.contains(el))
                                .cloned()
                                .collect()
                        })
                        .collect();

                    (id_batch_time, id_batch, lu_batch_time, lu_batch)
                })
                .collect()
        });

        // accumulate over batches
        batches_res
            .into_iter()
            .for_each(|(id_batch_time, id_batch, lu_batch_time, lu_batch)| {
                id_times.sum(id_batch_time.nullification, id_batch_time.id);
                lu_times.sum(lu_batch_time.extraction, lu_batch_time.lu);

                rsrs_factors.lu_factors[level_it].push(lu_batch);
                match &mut rsrs_factors.id_factors {
                    LevelIdFactors::Single(_) => todo!(),
                    LevelIdFactors::Batched(level_factors) => {
                        level_factors[level_it].push(id_batch)
                    }
                }
            });

        update_times.sum(0_u128, update_lu_batch_time);

        self.stats.dec_boxes_per_level.push(num_dec_boxes);
        self.stats.id_times.push(id_times);
        self.stats.lu_times.push(lu_times);
        self.stats.update_times.push(update_times);

        self.stats.tot_id_time += id_step_duration;
        self.stats.tot_lu_time += lu_step_duration;

        println!("ID and LU steps completed");
        println!("ID step in {id_step_duration}ms, with updates in {update_id_batch_time}ms");
        println!("LU step in {lu_step_duration}ms, with updates in {update_lu_batch_time}ms\n");
    }

    fn id_level_iteration<Space: SamplingSpace<F = Item>>(
        &mut self,
        current_box_indices: &[usize],
    ) -> (CommutativeFactors<Item>, Vec<usize>, Vec<Vec<usize>>) {
        println!("Starting ID step");
        let mut current_near_field_indices = Vec::new();
        current_box_indices
            .iter()
            .for_each(|box_ind| current_near_field_indices.push(self.get_near_indices(*box_ind)));
        let current_near_field_ind_to_num: HashMap<_, _> = current_box_indices
            .iter()
            .enumerate()
            .map(|(box_num, box_ind)| (*box_ind, box_num))
            .collect();

        let mut current_box_indices = current_box_indices.to_vec();
        current_box_indices.sort_by_key(|&box_ind| {
            let box_num = *current_near_field_ind_to_num.get(&box_ind).unwrap();
            let near_field_len = current_near_field_indices[box_num].len();
            let source_len = self.ind_s[box_ind].len();
            oversample::<Item>(
                near_field_len + source_len,
                self.options.sketching.oversampling,
                self.options.id_options.tol_id,
            )
        });
        let pool_threads = ThreadPoolBuilder::new()
            .num_threads(self.options.num_threads)
            .build()
            .unwrap();
        let start = Instant::now();
        let id_level_iteration_res: Vec<_> = pool_threads.install(|| {
            current_box_indices
                .par_iter()
                .map(|&box_ind| {
                    let box_num = *current_near_field_ind_to_num.get(&box_ind).unwrap();
                    let near_field_inds = &current_near_field_indices[box_num];
                    let os = oversample::<Item>(
                        near_field_inds.len() + self.ind_s[box_ind].len(),
                        self.options.sketching.oversampling,
                        self.options.id_options.tol_id,
                    );
                    let min_box_samples = local_oversample(os, self.active_samples);
                    let mut skel_box = <Item as Default>::default();

                    let rank = <Item as Skel<Item, Space>>::id_step(
                        &mut skel_box,
                        &self.box_types[box_ind],
                        &self.ind_s[box_ind],
                        near_field_inds,
                        &self.y_data,
                        &self.z_data,
                        min_box_samples,
                        &self.options,
                    );
                    (box_ind, rank)
                })
                .collect()
        });
        let id_level_duration = start.elapsed();
        println!("ID calculations in {id_level_duration:?}",);

        let start = Instant::now();
        let mut len_sketch = 0;
        let mut len_full_rank = 0;
        let mut num_dec_boxes = 0;
        let mut current_box_indices = Vec::new();
        let mut level_ind_r = Vec::new();
        let mut id_times = IdTimes::new();
        let mut id_level: CommutativeFactors<Item> = CommutativeFactorsOperations::new();

        id_level_iteration_res
            .into_iter()
            .for_each(|(box_ind, result)| match result {
                Rank::Low(low_rank_result) => {
                    current_box_indices.push(box_ind);
                    level_ind_r.push(low_rank_result.id_factor.ind_r.clone());
                    self.target_inds[box_ind] = low_rank_result.target_inds.clone();
                    self.ind_s[box_ind] = low_rank_result.id_factor.ind_s.clone();
                    self.ind_r.push(low_rank_result.id_factor.ind_r.clone());
                    let box_size = self.target_inds[box_ind].len();

                    let res_id_times = match low_rank_result.id_times {
                        Times::Lu(_lu_times) => IdTimes {
                            nullification: 0,
                            id: 0,
                        },
                        Times::Id(id_times) => id_times,
                    };

                    id_times.sum(res_id_times.nullification, res_id_times.id);

                    self.stats.ranks.push(self.ind_s[box_ind].len());
                    self.stats.box_sizes.push(box_size);
                    self.stats
                        .near_field_sizes
                        .push(low_rank_result.near_field_inds.len());

                    len_sketch += self.ind_s[box_ind].len();
                    num_dec_boxes += 1;

                    id_level.add_factor(Factor::Id(low_rank_result.id_factor));
                }
                Rank::Full(it_id_times) => {
                    len_full_rank += self.ind_s[box_ind].len();
                    let res_id_times = match it_id_times {
                        Times::Lu(_lu_times) => IdTimes {
                            nullification: 0,
                            id: 0,
                        },
                        Times::Id(id_times) => id_times,
                    };

                    id_times.sum(res_id_times.nullification, res_id_times.id);
                }
            });

        self.stats.dec_boxes_per_level.push(num_dec_boxes);
        self.stats.id_times.push(id_times);
        let id_level_duration = start.elapsed();
        println!("ID postprocessing in {id_level_duration:?}");

        (id_level, current_box_indices, level_ind_r)
    }

    fn lu_level_iteration<Space: SamplingSpace<F = Item>>(
        &mut self,
        current_box_indices: &[usize],
        level_ind_r: &[Vec<usize>],
        level_it: usize,
    ) -> Vec<CommutativeFactors<Item>> {
        println!("Start LU step");

        let start: Instant = Instant::now();
        let independent_near_fields = self.group_near_fields(current_box_indices);

        let level_near_field_inds: Vec<_> = current_box_indices
            .iter()
            .map(|&box_ind| self.get_near_indices(box_ind))
            .collect();

        let time_independent_nf = start.elapsed();

        self.stats.sorting_near_field += time_independent_nf.as_millis();

        println!("Batches computed in {time_independent_nf:?}");

        let mut update_parallel_batch_time = 0;
        let mut lu_times = LuTimes::new();
        let mut update_times = UpdateTimes::new();
        let lu_step_start: Instant = Instant::now();

        let mut inactive_inds = Vec::new();
        let pool_threads = ThreadPoolBuilder::new()
            .num_threads(self.options.num_threads)
            .build()
            .unwrap();
        let batches_res: Vec<_> = independent_near_fields
            .into_iter()
            .map(|batch| {
                let mut lu_batch: CommutativeFactors<Item> = CommutativeFactorsOperations::new();
                let mut lu_batch_time = LuTimes::new();
                let lu_times_and_factors: Vec<_> = pool_threads.install(|| {
                    batch
                        .par_iter()
                        .filter_map(|box_num| {
                            let skel_box = <Item as Default>::default();
                            let box_ind = current_box_indices[*box_num];
                            let os = oversample::<Item>(
                                self.target_inds[box_ind].len()
                                    + level_near_field_inds[*box_num].len(),
                                self.options.sketching.oversampling,
                                self.options.id_options.tol_id,
                            );
                            let min_num_samples = local_oversample(os, self.active_samples);
                            <Item as Skel<Item, Space>>::lu_step(
                                &skel_box,
                                &self.y_data,
                                &self.z_data,
                                &mut level_ind_r[*box_num].clone(),
                                &mut level_near_field_inds[*box_num].clone(),
                                &inactive_inds,
                                min_num_samples,
                                &self.options,
                            )
                            .map(|(lu_factor, lu_times)| {
                                (lu_times, lu_factor, level_ind_r[*box_num].clone())
                            })
                        })
                        .collect()
                });

                lu_times_and_factors
                    .into_iter()
                    .for_each(|(lu_time, lu_factor, r_inds)| {
                        lu_batch.add_factor(Factor::Lu(lu_factor));
                        inactive_inds.extend_from_slice(&r_inds);
                        match lu_time {
                            Times::Lu(lu_times) => {
                                lu_batch_time.sum(lu_times.lu, lu_times.extraction)
                            }
                            Times::Id(_id_times) => {}
                        }
                    });

                let parallel_batch_start: Instant = Instant::now();
                let update_type = UpdateType::Lu(&lu_batch);
                self.update_samples(0, self.active_samples, level_it, &update_type);
                let parallel_batch_duration = parallel_batch_start.elapsed().as_millis();
                update_parallel_batch_time += parallel_batch_duration;

                (lu_batch_time, lu_batch)
            })
            .collect();

        let batches_res: Vec<_> = batches_res
            .into_iter()
            .map(|(batch_lu_times, lu_batch)| {
                lu_times.sum(batch_lu_times.extraction, batch_lu_times.lu);
                lu_batch
            })
            .collect();

        update_times.sum(0_u128, update_parallel_batch_time);
        self.stats.lu_times.push(lu_times);
        self.stats.update_times.push(update_times);
        let lu_step_duration = lu_step_start.elapsed().as_millis() - update_parallel_batch_time;
        self.stats.tot_lu_time += lu_step_duration;
        println!(
            "LU step in {lu_step_duration}ms, with updates in {update_parallel_batch_time}ms\n"
        );

        batches_res
    }

    fn extract_step(&self) -> (CommutativeFactors<Item>, Vec<usize>, Vec<usize>) {
        let rows: Vec<usize> = (0..self.y_data.dim).collect();
        let mut acc_ind_s = Vec::new();
        let mut acc_ind_r = Vec::new();

        for inds in self.ind_s.iter() {
            acc_ind_s.extend_from_slice(inds);
        }

        for inds in self.ind_r.iter() {
            acc_ind_r.extend_from_slice(inds);
        }

        let mut cols = acc_ind_r;
        cols.extend_from_slice(&acc_ind_s);

        let remaining_indices = rows
            .clone()
            .into_iter()
            .filter(|&el| !cols.contains(&el))
            .collect::<Vec<_>>();
        cols.extend_from_slice(&remaining_indices);

        let pool_threads = ThreadPoolBuilder::new()
            .num_threads(self.options.num_threads)
            .build()
            .unwrap();

        let mut diag_box_factors: CommutativeFactors<Item> = CommutativeFactorsOperations::new();
        let mut diag_box_res: Vec<_> = pool_threads.install(|| {
            self.ind_r
                .par_iter()
                .map(|inds| {
                    DiagBoxFactor::new(
                        &mut inds.to_vec(),
                        &self.y_data,
                        self.active_samples,
                        &self.options,
                    )
                })
                .collect()
        });

        diag_box_res.push(DiagBoxFactor::new(
            &mut acc_ind_s.to_vec(),
            &self.y_data,
            self.active_samples,
            &self.options,
        ));

        diag_box_res.into_iter().for_each(|(dbres, _dbtime)| {
            diag_box_factors.add_factor(Factor::Diag(dbres.unwrap()));
        });

        (diag_box_factors, cols, rows)
    }

    fn get_near_indices(&mut self, box_ind: usize) -> Vec<usize> {
        let mut near_indices = Vec::new();
        for ind in self.near_inds[box_ind].iter() {
            near_indices.extend_from_slice(&self.target_inds[*ind]);
        }
        near_indices
    }

    fn get_level_indices(&mut self, level: usize) {
        println!("Computing Indices...\n");
        if level < self.level_indexing.max_level {
            // Step 1: Extract and snapshot keys before and after update
            let previous_level_keys: Vec<MortonKey> =
                self.level_indexing.level_keys.iter().cloned().collect();
            self.level_indexing.update_level_keys();
            let current_level_keys: Vec<MortonKey> =
                self.level_indexing.level_keys.iter().cloned().collect();

            // Step 2: Build index map from MortonKey to index
            let current_level_key_to_index: HashMap<_, _> = current_level_keys
                .iter()
                .enumerate()
                .map(|(i, key)| (*key, i))
                .collect();

            // Step 3: Allocate and initialize structures
            let num_boxes = current_level_keys.len();
            self.near_inds = vec![Vec::new(); num_boxes];
            let mut local_box_ranks = vec![Vec::new(); num_boxes];
            let mut box_types = vec![BoxType::Full(self.options.id_options.tol_id); num_boxes];
            let mut target_inds: Inds<usize> = vec![Vec::new(); num_boxes];
            let mut num_sons = vec![0; num_boxes];

            // Step 4: Migrate children to parent boxes
            for (box_ind, &box_key) in previous_level_keys.iter().enumerate() {
                if let Some(&parent_index) = current_level_key_to_index.get(&box_key.parent()) {
                    if self.ind_s[box_ind].len() < self.target_inds[box_ind].len() {
                        local_box_ranks[parent_index]
                            .push(BoxType::Merged::<Real<Item>>(self.ind_s[box_ind].len()));
                    }
                    target_inds[parent_index].extend_from_slice(&self.ind_s[box_ind]);
                    num_sons[parent_index] += 1;
                    self.ind_s[box_ind].clear();
                }
            }

            // Step 5: Handle orphan boxes (no children moved up)
            for (box_ind, &box_key) in previous_level_keys.iter().enumerate() {
                if let Some(&parent_index) = current_level_key_to_index.get(&box_key) {
                    if num_sons[parent_index] == 0 {
                        if self.level_indexing.max_level - level == 1 {
                            target_inds[parent_index].extend_from_slice(&self.target_inds[box_ind]);
                            self.target_inds[box_ind].clear();
                        } else {
                            target_inds[parent_index].extend_from_slice(&self.ind_s[box_ind]);
                            self.ind_s[box_ind].clear();
                        }
                        num_sons[parent_index] += 1;
                    }
                }
            }

            // Step 6: Update box types based on merged rank
            for (&_box_key, &parent_index) in current_level_key_to_index.iter() {
                let rank = pick_ranks(&self.options.rank_picking, &local_box_ranks[parent_index]);
                if let Some(min_rank) = rank {
                    let min_rank = min_rank.min(target_inds[parent_index].len());
                    box_types[parent_index] = BoxType::Merged(min_rank);
                } else if matches!(self.options.rank_picking, RankPicking::Tol) {
                    box_types[parent_index] = BoxType::Full(self.options.id_options.tol_id);
                }
            }

            // Step 7: Update self with new structures
            self.box_types = box_types;
            self.target_inds = target_inds;
            self.ind_s.clone_from(&self.target_inds);

            // Step 8: Build near field interaction indices
            for (box_key, &box_ind) in current_level_key_to_index.iter() {
                self.near_inds[box_ind].push(box_ind);

                let near_keys = self
                    .level_indexing
                    .get_box_near_field_keys(box_key, self.level_indexing.current_level);
                for near_box_key in &near_keys {
                    if let Some(&near_box_ind) = current_level_key_to_index.get(near_box_key) {
                        self.near_inds[box_ind].push(near_box_ind);
                    }
                }
            }

            // Step 9: Debug / info output
            let boxes_lengths: Vec<_> = self.ind_s.iter().map(Vec::len).collect();
            let active_indices = boxes_lengths.iter().sum::<usize>();

            println!(
                "New {} boxes, with {} active indices.",
                self.ind_s.len(),
                active_indices,
            );

            if self.stats.limiting_factors.limiting_level.active_points < active_indices {
                self.stats.limiting_factors.limiting_level.level =
                    self.level_indexing.current_level;
                self.stats.limiting_factors.limiting_level.active_points = active_indices;
                self.stats.limiting_factors.limiting_level.num_boxes = self.ind_s.len();
            }
        } else {
            let level_keys: Vec<MortonKey> =
                self.level_indexing.level_keys.iter().cloned().collect();
            let num_boxes = level_keys.len();

            // Resize all necessary structures once
            self.target_inds.resize(num_boxes, Vec::new());
            self.ind_s.resize(num_boxes, Vec::new());
            self.near_inds.resize(num_boxes, Vec::new());
            self.box_types
                .resize(num_boxes, BoxType::Full(self.options.id_options.tol_id));

            // Fill in target_inds and ind_s if at max level
            for (box_ind, box_key) in level_keys.iter().enumerate() {
                if let Some(box_indices) = self.level_indexing.boxes_map.get(box_key) {
                    self.target_inds[box_ind] = box_indices.clone();
                    if box_key.level() == self.level_indexing.max_level {
                        self.ind_s[box_ind] = box_indices.clone();
                    }
                }
            }

            // Build key-to-index map
            let key_to_index: HashMap<_, _> = level_keys
                .iter()
                .enumerate()
                .map(|(i, key)| (*key, i))
                .collect();

            // Fill near_inds
            for (box_key, &box_ind) in &key_to_index {
                self.near_inds[box_ind].push(box_ind);

                let near_keys = self
                    .level_indexing
                    .get_box_near_field_keys(box_key, self.level_indexing.current_level);
                for near_key in &near_keys {
                    if let Some(&near_ind) = key_to_index.get(near_key) {
                        self.near_inds[box_ind].push(near_ind);
                    }
                }
            }

            // Print box info
            let total_active: usize = self.target_inds.iter().map(Vec::len).sum();
            println!("New {num_boxes} boxes, and active indices: {total_active}");

            self.stats.limiting_factors.max_level = self.level_indexing.current_level;
        }
    }

    /*fn group_near_fields(&self, current_box_indices: &[usize]) -> Vec<Vec<usize>> {
        let n = current_box_indices.len();

        // ------------------------------------------
        // 1. Build neighbour sets for LOCAL indices
        // ------------------------------------------

        let mut neighbour_sets: Vec<FxHashSet<usize>> = Vec::with_capacity(n);

        for &box_id in current_box_indices {
            let mut s = FxHashSet::default();
            s.extend(self.near_inds[box_id].iter().copied());
            neighbour_sets.push(s);
        }

        // ------------------------------------------
        // 2. Build conflict graph:
        //    conflict(i,j) <=> share neighbours
        // ------------------------------------------

        let mut graph: Vec<Vec<usize>> = vec![Vec::new(); n];

        for i in 0..n {
            for j in (i + 1)..n {
                let si = &neighbour_sets[i];
                let sj = &neighbour_sets[j];

                let (small, big) = if si.len() <= sj.len() {
                    (si, sj)
                } else {
                    (sj, si)
                };

                let intersects = small.iter().any(|x| big.contains(x));

                if intersects {
                    graph[i].push(j);
                    graph[j].push(i);
                }
            }
        }

        // ------------------------------------------
        // 3. Greedy coloring (LOCAL indices)
        // ------------------------------------------

        let mut color = vec![usize::MAX; n];

        for node in 0..n {
            let mut forbidden = FxHashSet::default();

            // collect neighbor colors
            for &nb in &graph[node] {
                if color[nb] != usize::MAX {
                    forbidden.insert(color[nb]);
                }
            }

            // pick smallest available color
            let mut c = 0;
            while forbidden.contains(&c) {
                c += 1;
            }
            color[node] = c;
        }

        // ------------------------------------------
        // 4. Convert to LOCAL batches
        // ------------------------------------------

        let max_color = *color.iter().max().unwrap_or(&0);

        let mut batches: Vec<Vec<usize>> = vec![Vec::new(); max_color + 1];

        for (local_idx, &c) in color.iter().enumerate() {
            batches[c].push(local_idx); // push LOCAL index (0..n)
        }

        batches
    }*/

    /*fn group_near_fields_mis(&mut self, current_box_indices: &[usize]) -> Vec<Vec<usize>> {
        let n = current_box_indices.len();

        // ---------------------------------------------------------
        // 1. Build neighbour sets (global index space)
        //    One entry per LOCAL node 0..n-1
        // ---------------------------------------------------------
        let mut neighbour_sets = Vec::with_capacity(n);

        for &box_id in current_box_indices {
            let mut s = FxHashSet::default();
            s.extend(self.near_inds[box_id].iter().copied());
            neighbour_sets.push(s);
        }

        // Tracks which LOCAL nodes still remain
        let mut remaining = vec![true; n];

        // Output batches = MIS layers
        let mut layers: Vec<Vec<usize>> = Vec::new();

        // Conflict predicate: LOCAL i vs LOCAL j
        let conflicts = |i: usize, j: usize| -> bool {
            let si = &neighbour_sets[i];
            let sj = &neighbour_sets[j];

            if si.len() <= sj.len() {
                si.iter().any(|x| sj.contains(x))
            } else {
                sj.iter().any(|x| si.contains(x))
            }
        };

        // ---------------------------------------------------------
        // 2. MIS peeling (generate batches until no nodes remain)
        // ---------------------------------------------------------
        loop {
            // Collect remaining LOCAL nodes
            let candidates: Vec<usize> = remaining
                .iter()
                .enumerate()
                .filter(|(_, alive)| **alive)
                .map(|(i, _)| i)
                .collect();

            if candidates.is_empty() {
                break;
            }

            // Build MIS in LOCAL index space
            let mut mis = Vec::new();

            for &node in &candidates {
                if !remaining[node] {
                    continue;
                }
                if !mis.iter().any(|&m| conflicts(node, m)) {
                    mis.push(node);
                }
            }

            // === NEW CHECK: skip empty MIS layers (should never happen, but safe) ===
            if mis.is_empty() {
                break;
            }

            // Remove MIS nodes
            for &m in &mis {
                remaining[m] = false;
            }

            layers.push(mis);
        }

        // Final safety check: remove any accidental empty layers
        layers.retain(|layer| !layer.is_empty());

        layers
    }*/

    fn group_near_fields(&mut self, current_box_indices: &[usize]) -> Vec<Vec<usize>> {
        let num_indices = current_box_indices.len();
        let mut group_contents: Vec<FxHashSet<usize>> = Vec::with_capacity(num_indices);
        let mut group_indices: Vec<Vec<usize>> = Vec::with_capacity(num_indices);

        // You may later sort inds by neighbour-set size for better packing
        let inds = (0..num_indices).collect::<Vec<_>>();

        'outer: for ind in inds {
            let current_neighbors = &self.near_inds[current_box_indices[ind]];

            for (group_set, group) in group_contents.iter_mut().zip(group_indices.iter_mut()) {
                let has_overlap = current_neighbors.iter().any(|x| group_set.contains(x));

                if !has_overlap {
                    // Extend the group's neighbour set and add the index
                    group_set.extend(current_neighbors.iter().copied());
                    group.push(ind);
                    continue 'outer;
                }
            }

            // No compatible group found → create a new group
            let mut new_set = FxHashSet::default();
            new_set.extend(current_neighbors.iter().copied());
            group_contents.push(new_set);
            group_indices.push(vec![ind]);
        }

        // Remove any empty batches before returning
        group_indices
            .into_iter()
            .filter(|g| !g.is_empty())
            .collect()
    }
}

fn pick_ranks<Item: RlstScalar>(
    rank_picking: &RankPicking,
    local_box_ranks: &[BoxType<Item>],
) -> std::option::Option<usize> {
    match rank_picking {
        RankPicking::Min => local_box_ranks
            .iter()
            .filter_map(|b| match b {
                BoxType::Merged(rank) => Some(*rank),
                _ => None,
            })
            .min(),
        RankPicking::DoubleMin => {
            let min = local_box_ranks
                .iter()
                .filter_map(|b| match b {
                    BoxType::Merged(rank) => Some(2 * (*rank)),
                    _ => None,
                })
                .min();
            min
        }
        RankPicking::Max => local_box_ranks
            .iter()
            .filter_map(|b| match b {
                BoxType::Merged(rank) => Some(*rank),
                _ => None,
            })
            .max(),
        RankPicking::Avg => local_box_ranks
            .iter()
            .filter_map(|b| match b {
                BoxType::Merged(rank) => Some(*rank), // Dereference to get the value of rank
                _ => None,
            })
            .collect::<Vec<_>>() // Collect into a Vec
            .into_iter()
            .fold(None, |acc, rank| {
                match acc {
                    Some((sum, count)) => Some((sum + rank, count + 1)),
                    None => Some((rank, 1)), // Start with the first element
                }
            })
            .map(|(sum, count)| sum / count),
        RankPicking::Mid => {
            let min = local_box_ranks
                .iter()
                .filter_map(|b| match b {
                    BoxType::Merged(rank) => Some(*rank),
                    _ => None,
                })
                .min();
            let max = local_box_ranks
                .iter()
                .filter_map(|b| match b {
                    BoxType::Merged(rank) => Some(*rank),
                    _ => None,
                })
                .max();

            match (min, max) {
                (Some(min_val), Some(max_val)) => Some((min_val + max_val) / 2),
                _ => None,
            }
        }
        RankPicking::Tol => None,
    }
}
